import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../core/services/events_api_service.dart';
import '../../../core/services/snackbar_service.dart';
import 'event_utils.dart';
import 'news_event_item.dart';
import '../../../core/utils/calendar_utils.dart';

class EventDetailsPage extends StatefulWidget {
  final NewsEventItem item;
  const EventDetailsPage({super.key, required this.item});

  @override
  State<EventDetailsPage> createState() => _EventDetailsPageState();
}

class _EventDetailsPageState extends State<EventDetailsPage> {
  final PageController detailsPageController = PageController();
  int currentDetailsImageIndex = 0;

  @override
  void dispose() {
    detailsPageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final iconData = EventUtils.getEventIconData(
      "${item.iconName}-${item.category}",
    );

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // ==================== HERO HEADER — FIXED COVER IMAGE ====================
          SliverAppBar(
            expandedHeight: 300, // slightly taller for better visual balance
            pinned: true,
            backgroundColor: iconData.color,
            surfaceTintColor: Colors.transparent,
            elevation: 0,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.of(context).pop(),
            ),
            flexibleSpace: FlexibleSpaceBar(
              title: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Icon(iconData.icon, color: Colors.white, size: 26),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        item.title,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          shadows: [
                            Shadow(color: Colors.black54, blurRadius: 8),
                          ],
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
              background: Stack(
                fit: StackFit.expand,
                children: [
                  // Event-themed background (real apps use this when cover is logo-style)
                  Container(color: iconData.color.withOpacity(0.92)),

                  // Cover Image — Centered + Fully Visible (no cropping)
                  if (item.imageUrl.isNotEmpty)
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 40,
                          vertical: 20,
                        ),
                        child: CachedNetworkImage(
                          imageUrl: item.imageUrl,
                          fit: BoxFit.contain,
                          placeholder: (context, url) => const Center(
                            child: SizedBox(
                              width: 40,
                              height: 40,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                              ),
                            ),
                          ),
                          errorWidget: (context, url, error) => const Icon(
                            Icons.image,
                            color: Colors.white70,
                            size: 90,
                          ),
                        ),
                      ),
                    ),

                  // Bottom gradient for perfect title readability (standard in Eventbrite/Meetup)
                  const Align(
                    alignment: Alignment.bottomCenter,
                    child: SizedBox(
                      height: 140,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [Colors.transparent, Colors.black54],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              centerTitle: true,
            ),
          ),

          // ==================== (Rest of your page unchanged — Date, Description, Google Photos, Carousel) ====================
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.calendar_today,
                          size: 18,
                          color: Colors.grey.shade700,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          EventUtils.formatDate(item.date.toString()),
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: (item.status ?? 'unknown') == 'active'
                          ? Colors.green.withOpacity(0.12)
                          : Colors.red.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Text(
                      (item.status ?? 'unknown').toUpperCase(),
                      style: TextStyle(
                        color: (item.status ?? 'unknown') == 'active'
                            ? Colors.green
                            : Colors.red,
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: OutlinedButton.icon(
                onPressed: () async {
                  final url = CalendarUtils.generateGoogleCalendarUrl(
                    title: item.title,
                    description: item.shortDescription ?? '',
                    date: item.date,
                  );
                  final uri = Uri.parse(url);
                  if (await canLaunchUrl(uri)) {
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  }
                },
                icon: const Icon(Icons.event_available),
                label: const Text("Add to Google Calendar"),
                style: OutlinedButton.styleFrom(
                  foregroundColor: iconData.color,
                  side: BorderSide(color: iconData.color),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ),

          // Description, Google Photos, and Carousel sections remain exactly the same as your last version
          // (I kept them identical so you can just copy-paste the whole thing)
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Description",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: iconData.color,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    item.shortDescription ?? 'No short description available.',
                    style: const TextStyle(fontSize: 17, height: 1.5),
                  ),
                  const SizedBox(height: 20),
                  HtmlWidget(
                    item.longDescription ?? 'No long description available.',
                    textStyle: const TextStyle(fontSize: 16, height: 1.6),
                  ),
                ],
              ),
            ),
          ),

          if (item.googlePhotosLink != null &&
              item.googlePhotosLink!.trim().isNotEmpty)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                child: InkWell(
                  onTap: () async {
                    final link = item.googlePhotosLink!.trim();
                    final uri = Uri.parse(
                      link.startsWith('http') ? link : 'https://$link',
                    );
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(
                        uri,
                        mode: LaunchMode.externalApplication,
                      );
                    } else {
                      SnackbarService.show(
                        "Could not launch link",
                        type: SnackbarType.error,
                      );
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: Colors.blue.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.blue.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.photo_library,
                          color: Colors.blue,
                          size: 28,
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "Google Photos Album",
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                              Text(
                                item.googlePhotosLink!,
                                style: const TextStyle(color: Colors.blue),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                        const Icon(
                          Icons.arrow_forward_ios,
                          size: 20,
                          color: Colors.blue,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

          if (item.eventImages != null && item.eventImages!.isNotEmpty)
            SliverToBoxAdapter(
              child: Builder(
                builder: (context) {
                  List<String> images = [];
                  final jsonStr = item.eventImages;
                  if (jsonStr != null && jsonStr.isNotEmpty) {
                    try {
                      final decoded = jsonDecode(jsonStr);
                      images = (decoded is List)
                          ? decoded.map((e) => e.toString()).toList()
                          : [jsonStr];
                    } catch (_) {
                      images = [jsonStr];
                    }
                  }
                  if (images.isEmpty) return const SizedBox.shrink();

                  return Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 40),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Event Images",
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: iconData.color,
                          ),
                        ),
                        const SizedBox(height: 16),
                        Container(
                          height: 340,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.07),
                                blurRadius: 15,
                              ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: Stack(
                              children: [
                                PageView.builder(
                                  controller: detailsPageController,
                                  itemCount: images.length,
                                  onPageChanged: (index) => setState(
                                    () => currentDetailsImageIndex = index,
                                  ),
                                  itemBuilder: (context, i) => CachedNetworkImage(
                                    imageUrl:
                                        "${EventsApiService.eventsImageUrl}${images[i]}",
                                    fit: BoxFit.contain,
                                    placeholder: (context, url) => const Center(
                                      child: SizedBox(
                                        width: 34,
                                        height: 34,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 3,
                                        ),
                                      ),
                                    ),
                                    errorWidget: (context, url, error) =>
                                        const Center(
                                          child: Icon(
                                            Icons.broken_image,
                                            size: 60,
                                          ),
                                        ),
                                  ),
                                ),
                                if (images.length > 1) ...[
                                  Positioned(
                                    left: 12,
                                    top: 140,
                                    child: _buildNavButton(Icons.chevron_left),
                                  ),
                                  Positioned(
                                    right: 12,
                                    top: 140,
                                    child: _buildNavButton(Icons.chevron_right),
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        if (images.length > 1)
                          Center(
                            child: Text(
                              "${currentDetailsImageIndex + 1} / ${images.length}",
                              style: TextStyle(
                                color: Colors.grey.shade600,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                      ],
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildNavButton(IconData icon) {
    return CircleAvatar(
      backgroundColor: Colors.black.withOpacity(0.5),
      child: IconButton(
        icon: Icon(icon, color: Colors.white),
        onPressed: () {
          if (icon == Icons.chevron_left) {
            detailsPageController.previousPage(
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeInOut,
            );
          } else {
            detailsPageController.nextPage(
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeInOut,
            );
          }
        },
      ),
    );
  }
}
