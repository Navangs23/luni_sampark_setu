import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_colors.dart';
import 'event_utils.dart';
import 'news_event_details_view.dart';
import 'news_event_item.dart';
import 'news_events_viewmodel.dart';

class NewsEventsView extends StatefulWidget {
  const NewsEventsView({super.key});

  @override
  State<NewsEventsView> createState() => _NewsEventsViewState();
}

class _NewsEventsViewState extends State<NewsEventsView> {
  @override
  void initState() {
    super.initState();

    Future.microtask(() {
      context.read<NewsEventsViewModel>().fetchEvents();
    });
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<NewsEventsViewModel>();
    final theme = Theme.of(context);

    /// LOADING STATE
    if (vm.loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () => vm.fetchEvents(),
        child: vm.items.isEmpty
            ? const Center(child: Text("No Events Available"))
            : ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: vm.items.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, index) {
                  final item = vm.items[index];
                  return _NewsEventCard(item: item, theme: theme);
                },
              ),
      ),
    );
  }
}

class _NewsEventCard extends StatelessWidget {
  final NewsEventItem item;
  final ThemeData theme;

  const _NewsEventCard({required this.item, required this.theme});

  @override
  Widget build(BuildContext context) {
    final iconData = EventUtils.getEventIconData(
      "${item.iconName}-${item.category}",
    );

    final icon = iconData.icon;
    final color = iconData.color;

    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: color),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => EventDetailsPage(item: item)),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// HEADER
              Row(
                children: [
                  CircleAvatar(
                    radius: 18,
                    backgroundColor: color.withOpacity(0.15),
                    child: Icon(icon, size: 18, color: color),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      item.iconName.replaceAll("_", " ").toUpperCase(),
                      style: theme.textTheme.bodySmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: color,
                      ),
                    ),
                  ),
                  Text(
                    EventUtils.formatDate(item.date.toString()),
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),

              Divider(height: 20, color: color),

              /// CONTENT
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// IMAGE
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      border: Border.all(color: color, width: 1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.all(2),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: FadeInImage.assetNetwork(
                        placeholder: 'assets/icons/app_logo.png',
                        image: item.imageUrl,
                        width: 80,
                        height: 80,
                        fit: BoxFit.contain,
                        fadeInDuration: const Duration(milliseconds: 200),
                        imageErrorBuilder: (context, error, stackTrace) {
                          return Container(
                            color: Colors.grey.shade200,
                            child: const Icon(
                              Icons.image_not_supported,
                              size: 30,
                              color: Colors.grey,
                            ),
                          );
                        },
                      ),
                    ),
                  ),

                  const SizedBox(width: 12),

                  /// TEXT - UPDATED HERE
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.title,
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          item.shortDescription ??
                              item.longDescription ??
                              'No description available.',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
