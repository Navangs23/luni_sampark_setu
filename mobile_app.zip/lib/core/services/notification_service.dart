import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:luni_sampark_setu/core/services/navigation_service.dart';
import 'package:luni_sampark_setu/ui/home/advertisements/advertisements_view.dart';
import 'package:luni_sampark_setu/ui/home/downloads/downloads_view.dart';
import 'package:luni_sampark_setu/ui/home/gallery/gallery_view.dart';
import 'package:luni_sampark_setu/ui/home/live%20stream/livestream_view.dart';
import 'package:luni_sampark_setu/ui/home/shell/home_shell_viewmodel.dart';
import 'package:provider/provider.dart';

class NotificationService {
  static final FirebaseMessaging _messaging = FirebaseMessaging.instance;

  static Future<void> init() async {
    // 1. Request Permission
    NotificationSettings settings = await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      debugPrint('User granted permission');
    } else {
      debugPrint('User declined or has not accepted permission');
    }

    // 2. Enable Foreground Notifications (Heads-up)
    await _messaging.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );

    // 3. Subscribe to "all" topic
    try {
      await _messaging.subscribeToTopic('all');
      debugPrint('Successfully subscribed to topic: all');
    } catch (e) {
      debugPrint('Failed to subscribe to topic all: $e');
    }

    // 3. Handle Token (for debugging/admin panel)
    String? token = await _messaging.getToken();
    debugPrint("FCM Token: $token");

    // 4. Listeners
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      debugPrint("Foreground message received: ${message.notification?.title}");
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      debugPrint("Notification clicked: ${message.data}");
      _handleMessageNavigation(message.data);
    });

    // 5. Check if app was opened from terminated state via notification
    RemoteMessage? initialMessage = await _messaging.getInitialMessage();
    if (initialMessage != null) {
      _handleMessageNavigation(initialMessage.data);
    }
  }

  static void _handleMessageNavigation(Map<String, dynamic> data) {
    final String? type = data['type'];
    final context = NavigationService.navigatorKey.currentContext;
    
    switch (type) {
      case 'photo_gallery':
        NavigationService.push(const GalleryView());
        break;
      case 'ads':
        NavigationService.push(const AdvertisementsView());
        break;
      case 'live_stream':
        NavigationService.push(const LiveStreamView());
        break;
      case 'downloads':
        NavigationService.push(const DownloadsView());
        break;
      case 'news':
      case 'event':
        // Switch to News tab (Index 0)
        context?.read<HomeShellViewModel>().setIndex(0);
        // Pop any pushed views to return to the shell
        NavigationService.navigatorKey.currentState?.popUntil((route) => route.isFirst);
        break;
      default:
        debugPrint("Unknown notification type: $type");
    }
  }
}
